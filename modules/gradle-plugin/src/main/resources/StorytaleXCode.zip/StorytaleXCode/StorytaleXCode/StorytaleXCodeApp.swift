//
//  StorytaleXCodeApp.swift
//  StorytaleXCode
//
//  Created by Artem.Kobzar on 7/10/24.
//

import SwiftUI

@main
struct StorytaleXCodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
